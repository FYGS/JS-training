# example_jao

javascript example

## Author

Jean-Louis GUENEGO

My website is [JLG Consulting](https://www.jlg-consulting.com/fr/home)

import blockchain from './blockchain'; // ES6 import notation.

blockchain.add('Alice gives 5 dollars to Bob.');
blockchain.add('Bob gives 3 dollars to Charly.');

blockchain.log();


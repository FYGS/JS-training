console.log('Hello this is a log...');
const a = Math.pow(2, 4);
console.log('2 power 4 is 2 * 2 * 2 * 2 so it is %d.', a);


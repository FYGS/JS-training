// 'use strict';

// const
 foo = 'bar';
console.log('foo', foo);

(function() {
    console.log('this', this);
})();


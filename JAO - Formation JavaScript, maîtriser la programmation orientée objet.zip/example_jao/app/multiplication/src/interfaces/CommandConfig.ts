export interface CommandConfig {
  sampleNbr: number;
  multiplicationFactor: number;
}

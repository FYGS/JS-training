import { Board } from './classes/Board';
import { Command } from './classes/Command';
import { CommandConfig } from './interfaces/CommandConfig';

import './style.css';

const board = new Board();

setTimeout(() => {
	board.config = {
		sampleNbr: 50,
		multiplicationFactor: 3,
	};
	board.draw();
}, 2000);

const command = new Command(board.config);
command.onUpdate((config: CommandConfig)=> {
	board.config = config;
});

console.log('this', this); // undefined
console.log('globalThis', globalThis);
// use npx serve to launch !

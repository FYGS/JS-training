import { CommandConfig } from '../interfaces/CommandConfig';
import { querySelector } from '../utils';
import { Line } from './Line';
import { Point } from './Point';
export class Board {
	private pConfig: CommandConfig = {
		sampleNbr: 20,
		multiplicationFactor: 3,
	};

	set config(configObject) {
		this.pConfig = configObject;
		this.draw();
	}

	get config() {
		return this.pConfig;
	}

	constructor() {
		this.draw();
	}

	draw() {
		this.clean();
		this.drawPoints();
		this.drawLines();
	}

	drawPoints() {
		for (let i = 0; i < this.pConfig.sampleNbr; i++) {
			Point.getFromIndex(i, this.pConfig.sampleNbr).draw();
		}
	}

	drawLines() {
		for (let i = 0; i < this.pConfig.sampleNbr; i++) {
			Line.getFromIndexes(
				i,
				i * this.pConfig.multiplicationFactor,
				this.pConfig.sampleNbr,
			).draw();
		}
	}

	clean() {
		['g.points', 'g.lines'].forEach(sel => querySelector(sel).innerHTML = '');
	}
}

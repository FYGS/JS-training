import { querySelector } from '../utils';
import { Drawable } from './Drawable';

const svgns = 'http://www.w3.org/2000/svg';

const cx0 = 50;
const cy0 = 50;
const r0 = 45;
export class Point extends Drawable {
	constructor(readonly x: number, readonly y: number) {
		super();
	}

	static getFromAngle = function (angle: number) {
		const cx = cx0 + r0 * Math.cos(angle);
		const cy = cy0 + r0 * Math.sin(angle);

		return new Point(cx, cy);
	};

	static getFromIndex(index: number, sampleNbr: number) {
		return Point.getFromAngle(Point.getAngleFromIndex(index, sampleNbr));
	}

	override draw() {
		const gPoints = querySelector('g.points');
		const circle = document.createElementNS(svgns, 'circle');
		circle.setAttributeNS(null, 'cx', `${this.x}`);
		circle.setAttributeNS(null, 'cy', '' + this.y);
		circle.setAttributeNS(null, 'r', '1');
		gPoints.appendChild(circle);
	}

	static getAngleFromIndex(index: number, sampleNbr: number) {
		return (index * Math.PI * 2) / sampleNbr;
	}
}

console.log('typeof 2', typeof 2);
console.log('typeof "2"', typeof "2");
console.log('typeof false', typeof false);
console.log('typeof undefined', typeof undefined);
console.log('typeof function() {}', typeof function() {});
console.log('typeof () => {})', typeof (() => {}));
console.log('typeof class {})', typeof class {});
console.log('typeof {}', typeof {});
console.log('typeof new class {}', typeof new class {});
console.log('typeof Object', typeof Object);
console.log('typeof null', typeof null);
console.log('typeof NaN', typeof NaN);
console.log('typeof +"2"', typeof +"2");



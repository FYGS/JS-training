const fs = require('fs');

fs.appendFileSync('kiki.txt', 'hello1\n');
fs.appendFileSync('kiki.txt', 'hello2\n');
fs.appendFileSync('kiki.txt', 'hello3\n');
fs.appendFileSync('kiki.txt', 'hello4\n');

console.log('Hello this is a log...');
const div = document.querySelector('div');
div.innerHTML = 'Hello world!';

export abstract class Drawable {
  abstract draw(): void;
}
